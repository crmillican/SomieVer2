// Entry point script to start the projections server
import './projections-server.js';